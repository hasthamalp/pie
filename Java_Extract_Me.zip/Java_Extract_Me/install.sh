sudo apt update
sudo rm -r /usr/lib/jvm/
sudo mkdir /usr/lib/jvm/
sudo mkdir /usr/lib/mozilla
sudo mkdir /usr/lib/mozilla/plugins
cd files/
sudo cp jre-8u261-linux-x64.tar.gz /usr/lib/jvm/jre-8u261-linux-x64.tar.gz
sudo cp exception.sites ~/exception.sites
cd /usr/lib/jvm/
sudo tar -xvzf jre-8u261-linux-x64.tar.gz
sudo rm -r jre-8u261-linux-x64.tar.gz
sudo ln -sf /usr/lib/jvm/jre1.8.0_261/bin/ControlPanel /usr/bin/ControlPanel
		sudo ln -sf /usr/lib/jvm/jre1.8.0_261/bin/java  /usr/bin/java
		sudo ln -sf /usr/lib/jvm/jre1.8.0_261/bin/javaws  /usr/bin/javaws
		sudo ln -sf /usr/lib/jvm/jre1.8.0_261/bin/jcontrol  /usr/bin/jcontrol
		sudo ln -sf /usr/lib/jvm/jre1.8.0_261/bin/jjs  /usr/bin/jjs
		sudo ln -sf /usr/lib/jvm/jre1.8.0_261/bin/keytool  /usr/bin/keytool
		sudo ln -sf /usr/lib/jvm/jre1.8.0_261/bin/orbd  /usr/bin/orbd
		sudo ln -sf /usr/lib/jvm/jre1.8.0_261/bin/pack200  /usr/bin/pack200
		sudo ln -sf /usr/lib/jvm/jre1.8.0_261/bin/policytool  /usr/bin/policytool
		sudo ln -sf /usr/lib/jvm/jre1.8.0_261/bin/rmid  /usr/bin/rmid
		sudo ln -sf /usr/lib/jvm/jre1.8.0_261/bin/rmiregistry  /usr/bin/rmiregistry
		sudo ln -sf /usr/lib/jvm/jre1.8.0_261/bin/servertool  /usr/bin/servertool
		sudo ln -sf /usr/lib/jvm/jre1.8.0_261/bin/tnameserv  /usr/bin/tnameserv
		sudo ln -sf /usr/lib/jvm/jre1.8.0_261/bin/unpack200  /usr/bin/unpack200
		sudo ln -sf /usr/lib/jvm/jre1.8.0_261/lib/jexec  /usr/bin/jexec
		sudo ln -sf /usr/lib/jvm/jre1.8.0_261/lib/amd64/libnpjp2.so /usr/lib/mozilla/plugins/libjavaplugin.so
		sudo ln -sf /usr/lib/jvm/jre1.8.0_261/lib/amd64/libnpjp2.so /usr/lib/firefox/plugins/libjavaplugin.so
		sudo ln -sf /usr/lib/jvm/jre1.8.0_261/lib/amd64/libnpjp2.so /usr/lib/firefox-addons/plugins/libjavaplugin.so
