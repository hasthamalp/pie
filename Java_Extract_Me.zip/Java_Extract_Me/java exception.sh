sudo rm -r ~/.java/deployment/security/exception.sites
sudo cp files/exception.sites ~/.java/deployment/security/exception.sites
sudo chmod 777 ~/.java/deployment/security/exception.sites
